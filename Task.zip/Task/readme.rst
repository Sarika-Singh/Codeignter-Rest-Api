//
- Config 
- baseurl : https://localhost/Task

- view used : 
views/api_view.php

- controllers :
Api : Staffdetailapi.php
accessing Controler : Test_api.php

- Model:
StaffModel.php